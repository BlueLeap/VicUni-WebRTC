/*
* This has common JS functions used accross the site
* 
*/

$(document).ready(function() {
	$('.date_field').mask('00/00/0000');

	 $('#accordion').accordion({	
	        icons: { 
	        		header: 'ui-icon-plus', 
	        		activeHeader: 'ui-icon-triangle-1-s',
	        		headerSelected: 'ui-icon-minus' 
	        },
	 
		 beforeActivate: function(event, ui) {
	         // The accordion believes a panel is being opened
		        if (ui.newHeader[0]) {
		            var currHeader  = ui.newHeader;
		            var currContent = currHeader.next('.ui-accordion-content');
		         // The accordion believes a panel is being closed
		        } else {
		            var currHeader  = ui.oldHeader;
		            var currContent = currHeader.next('.ui-accordion-content');
		        }
		         // Since we've changed the default behavior, this detects the actual status
		        var isPanelSelected = currHeader.attr('aria-selected') == 'true';
		
		         // Toggle the panel's header
		        currHeader.toggleClass('ui-corner-all',isPanelSelected).toggleClass('accordion-header-active ui-state-active ui-corner-top',!isPanelSelected).attr('aria-selected',((!isPanelSelected).toString()));
		
		        // Toggle the panel's icon
		        currHeader.children('.ui-icon').toggleClass('ui-icon-triangle-1-e',isPanelSelected).toggleClass('ui-icon-triangle-1-s',!isPanelSelected);
		
		         // Toggle the panel's content
		        currContent.toggleClass('accordion-content-active',!isPanelSelected)    
		        if (isPanelSelected) { currContent.slideUp(); }  else { currContent.slideDown(); }
		
		        return false; // Cancel the default action
		 	}
		 });
	$.validator.addMethod(
		"europeanDate",
		function(value, element) {
			return value.match(/[\d]{2}\/[\d]{2}\/[\d]{4}/);
		},
		"Please enter a date in the format dd/mm/yyyy."
	);
	$.validator.addMethod(
		"minDateYear",
		function(value, element) {
			var dateChunks = value.split('/');
			if( dateChunks[2] >= 2000)
				return true;
			return false;
		},
		"Please enter a correct year."
	);


	 $("#incident_thread_update_form").validate({  
			rules:{
				update_incident_thread_ta: {
					required:true
				}
		    }, 
		    messages:{
		    	update_incident_thread_ta: {
		    		update_incident_thread_ta: "Please enter a value to submit."
		    	}
		    },
		    highlight: function(element) {
		        $(element).removeClass('success').addClass('error');
		        $(element).closest("div").addClass("error");
		     },
		     success: function(element) {
		    	 $(element).addClass('valid').removeClass('error').addClass('success');
		    	 $(element).closest("div").removeClass("error");
		    	 if($(element).attr('for') == 'phoneGroup'){
		    		 $('#pd_mobilephone').closest("div").removeClass("error");
		    	 }
		     }
	  });
});