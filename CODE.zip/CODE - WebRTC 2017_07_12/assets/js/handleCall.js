//TRY TYPING IN ONE OF THESE NUMBERS:
//
// 1234567890
// 0651985833
//
$(function () {
    $("#phone-number").focus();
    $("#caller_btn").attr("onclick", "makeCall(this)");
    var connection;
//    window.onkeyup = function (e) {
//        
//        var key = e.keyCode ? e.keyCode : e.which;
//
//        if ((key >= 48 && key <= 57) || (key >= 96 && key <= 105)) {
//            var currentValue = $('.phoneString input').val();
//            var valueToAppend = e.key;
//            $('.phoneString input').val(currentValue + valueToAppend);
//        }
//        if (key == 46 || key == 8)
//        {
//            deleteChar(false);
//            
//        }
//    };
    init();
});

function init()
{
    console.log('inside init');
    $.getJSON('/token.php')
            .done(function (data) {
                log('Got a token.');
                console.log('Token: ' + data.token);

                // Setup Twilio.Device
                Twilio.Device.setup(data.token);

                Twilio.Device.ready(function (device) {
                    console.log(device);
                    log('Twilio.Device Ready!');
                    $("#caller_btn").css('pointer-events', 'auto')
                });

                Twilio.Device.error(function (error) {
                    console.log(error);
                    log('Twilio.Device Error: ' + error.message);
                    if (error.code == 31205)
                    {
                        init();
                        return;
                    }
                    // reset screen
                });

                Twilio.Device.connect(function (conn) {

                    connection = conn;
                    log('Successfully established call!');
                    connection.mute(function (flag, connectionObj) {
                        if (flag)
                        {

                        }
                        else
                        {

                        }
                    });
                    timeoutTimer = true;
                    looper();
                    //showActiveCallAfterAFewSeconds

                    timeoutTimer = false;
                    timeCounterCounting = true;
                    timeCounterLoop();

                    $('.pulsate').toggleClass('active-call');
                    $('.ca-status').animate({
                        opacity: 0,
                    }, 500, function () {
                        $(this).text('00:00');
                        $('.ca-status').attr('data-dots', '');

                        $('.ca-status').animate({
                            opacity: 1,
                        }, 500);
                    });



                    // show timer

                });

                Twilio.Device.disconnect(function (conn) {
                    log('Call ended.');
                    console.log(conn);
                    handleHangUpUi();
                    getCallDuration(conn.parameters.CallSid);
                });




            })
            .fail(function () {
                log('Could not get a token from server!');
            });
}

$('.number-dig').click(function () {
    //add animation
    $("#phone-number").focus();
    addAnimationToButton(this);
    //add number
    var currentValue = $('.phoneString input').val();
    var valueToAppend = $(this).attr('name');
    $('.phoneString input').val(currentValue + valueToAppend);

    checkNumber();
});


var timeoutTimer = true;
var timeCounter = 0;
var timeCounterCounting = true;
var deleteChar = function (button)
{
    $("#phone-number").focus();
    
    var currentValue = $('.phoneString input').val();
    var newValue = currentValue.substring(0, currentValue.length - 1);
    $('.phoneString input').val(newValue);
    checkNumber();
};
var makeCall = function (button)
{
    addAnimationToButton(button);
    var params = {
        To: document.getElementById('phone-number').value
    };

    console.log('Calling ' + params.To + '...');
    Twilio.Device.connect(params);
    handleMakeCallUi();
}
var handleMakeCallUi = function ()
{
    $(".ca-number").text($("#phone-number").val());
    $('.ca-status').text('Calling');
    $("#caller_btn").attr("onclick", 'hangUp(this)');
    setToInCall();


}
var hangUp = function (button)
{

    addAnimationToButton(button);
    log('Hanging up...');
    Twilio.Device.disconnectAll();


}
var handleHangUpUi = function ()
{
    setTimeout(function () {
        setToInCall();
    }, 500);
    timeCounterCounting = false;
    timeCounter = 0;
    hangUpCall();
    $('.pulsate').toggleClass('active-call');

    $('.phoneString input').val('');
    checkNumber();
    $("#caller_btn").attr("onclick", "makeCall(this)");
}
//$('.action-dig').click(function () {
//    //add animation
//    addAnimationToButton(this);
//    if ($(this).hasClass('goBack')) {
//        var currentValue = $('.phoneString input').val();
//        var newValue = currentValue.substring(0, currentValue.length - 1);
//        $('.phoneString input').val(newValue);
//        checkNumber();
//    } else if ($(this).hasClass('call')) {
//        if ($('.call-pad').hasClass('in-call')) {
//            log('Hanging up...');
//            Twilio.Device.disconnectAll();
//            setTimeout(function () {
//                setToInCall();
//            }, 500);
//            timeCounterCounting = false;
//            timeCounter = 0;
//            hangUpCall();
//            $('.pulsate').toggleClass('active-call');
//
//            $('.phoneString input').val('');
//            checkNumber();
//        } else {
//            var params = {
//                To: document.getElementById('phone-number').value
//            };
//
//            console.log('Calling ' + params.To + '...');
//            Twilio.Device.connect(params);
//            $('.ca-status').text('Calling');
//            setTimeout(function () {
//                setToInCall();
//                timeoutTimer = true;
//                looper();
//                //showActiveCallAfterAFewSeconds
//                setTimeout(function () {
//                    timeoutTimer = false;
//                    timeCounterCounting = true;
//                    timeCounterLoop();
//
//                    $('.pulsate').toggleClass('active-call');
//                    $('.ca-status').animate({
//                        opacity: 0,
//                    }, 1000, function () {
//                        $(this).text('00:00');
//                        $('.ca-status').attr('data-dots', '');
//
//                        $('.ca-status').animate({
//                            opacity: 1,
//                        }, 1000);
//                    });
//                }, 3000);
//            }, 500);
//        }
//    } else {
//
//    }
//});
var openDialer = function ()
{

}
var sendDtmf = function (value)
{
    connection.sendDigits(value);
}
var mute = function (flag)
{
    connection.mute(flag);
}
var timeCounterLoop = function () {

    if (timeCounterCounting) {
        setTimeout(function () {
            var timeStringSeconds = '';
            var minutes = Math.floor(timeCounter / 60.0);
            var seconds = timeCounter % 60;
            if (minutes < 10) {
                minutes = '0' + minutes;
            }
            if (seconds < 10) {
                seconds = '0' + seconds;
            }
            $('.ca-status').text(minutes + ':' + seconds);

            timeCounter += 1;

            timeCounterLoop();
        }, 1000);
    }
};

var setToInCall = function () {
    $('.call-pad').toggleClass('in-call');
    $('.call-icon').toggleClass('in-call');
    $('.call-change').toggleClass('in-call');
    $('.ca-avatar').toggleClass('in-call');

};
var getCallDuration = function(callSID)
{
    $.getJSON('/getCallDetails.php?callSID='+callSID)
            .done(function (data) {
               log('Call Duration '+data); 
            });
}

var dots = 0;
var looper = function () {
    if (timeoutTimer) {

        setTimeout(function () {
            if (dots > 3) {
                dots = 0;
            }
            var dotsString = '';
            for (var i = 0; i < dots; i++) {
                dotsString += '.';
            }
            $('.ca-status').attr('data-dots', dotsString);
            dots += 1;

            looper();
        }, 500);
    }
};

var hangUpCall = function () {
    timeoutTimer = false;
};

var addAnimationToButton = function (thisButton) {
    console.log(1);
    //add animation
    $(thisButton).removeClass('clicked');
    var _this = thisButton;
    setTimeout(function () {
        $(_this).addClass('clicked');
    }, 1);
};

var checkNumber = function () {
    var numberToCheck = $('.phoneString input').val();
    var contactMatt = {
        name: 'Matt Sich',
        number: '123456789',
        image: 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/378978/profile/profile-80_1.jpg',
        desc: 'CodePenner'
    };
    var contactHellogiov = {
        name: 'hellogiov',
        number: '0651985833',
        image: 'http://avatars-cdn.producthunt.com/207787/220',
        desc: 'Publicis Nurun'
    };
    if (numberToCheck.length > 0 && contactMatt.number.substring(0, numberToCheck.length) == numberToCheck) {
        //show this contact!
        showUserInfo(contactMatt);
    } else if (numberToCheck.length > 0 && contactHellogiov.number.substring(0, numberToCheck.length) == numberToCheck) {
        showUserInfo(contactHellogiov);
    } else {
        hideUserInfo();
    }
};

var showUserInfo = function (userInfo) {
    $('.avatar').attr('style', "background-image: url(" + userInfo.image + ")");
    if (!$('.contact').hasClass('showContact')) {
        $('.contact').addClass('showContact');
    }
    $('.contact-name').text(userInfo.name);
    $('.contact-position').text(userInfo.desc);
    var matchedNumbers = $('.phoneString input').val();
    var remainingNumbers = userInfo.number.substring(matchedNumbers.length);
    $('.contact-number').html("<span>" + matchedNumbers + "</span>" + remainingNumbers);

    //update call elements
    $('.ca-avatar').attr('style', 'background-image: url(' + userInfo.image + ')');
    $('.ca-name').text(userInfo.name);
    $('.ca-number').text(userInfo.number);

};

var hideUserInfo = function () {
    $('.contact').removeClass('showContact');
};

function log(message) {
    var logDiv = document.getElementById('log');
    logDiv.innerHTML += '<p>&gt;&nbsp;' + message + '</p>';
    logDiv.scrollTop = logDiv.scrollHeight;
}

