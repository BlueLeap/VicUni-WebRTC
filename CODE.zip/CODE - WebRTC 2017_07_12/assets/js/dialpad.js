/* ==========================================================================
   main.js
   ========================================================================== */
var $j = jQuery.noConflict();

    var index;
    var dials;
    var number;
    var total;
    var timeCounter = 0;
    var timeCounterCounting = true;
$j(function(){

    dials = $j(".dials ol li");
    number = $j(".number");
    number.empty();
    $(".number").bind('DOMSubtreeModified',function(){
        console.log('Test',$(this).text().length);
        if($(this).text().length>=9)
            $(".pad-action").removeClass("disabled");
        else
            $(".pad-action").addClass("disabled");
    });
    $('.openMenu').on('click',function(){
        number.empty().append($(this).data('phone'));
    });
    
    dials.click(function(){
         index = dials.index(this);
         console.log(index);
        if((number.text().length==13) && (index!=12 && index!=13 && index!=14))
            return false;
       

        if(index == 9){

            number.append("*");

        }else if(index == 10){

            number.append("0"); 

        }else if(index == 11){

            number.append("#");

        }else if(index == 12){

            number.empty();

        }else if(index == 13){
 
            total = number.text();
            total = total.slice(0,-1);
            number.empty().append(total);

        }else if(index == 14){
            callStarted();
           

        }else if(index == 15){
            callEnded();
            

        }else{ number.append(index+1); }
    });
    
    $j(document).keydown(function(e){
        var key = e.keyCode ? e.keyCode : e.which;
        if(number.text().length==13 && (key >= 48 && key <= 57) || (key >= 96 && key <= 105))
            return false;
        

       if ((key >= 48 && key <= 57) || (key >= 96 && key <= 105)) {
           number.append(e.key);
       }
       if (key == 46 || key == 8)
       {
           total = number.text();
                total = total.slice(0,-1);
                number.empty().append(total);
           
       }
       if(key == 27)
       {
        number.empty();
       }
       if(key==13)
        $('.pad-action').click();
        // switch(e.which){

        //     case 96:

        //         number.append("0");
        //         break;

        //     case 97:

        //         number.append("1");
        //         break;

        //     case 98:

        //         number.append("2");
        //         break;

        //     case 99:

        //         number.append("3");
        //         break;

        //     case 100:

        //         number.append("4");
        //         break;

        //     case 101:

        //         number.append("5");
        //         break;

        //     case 102:

        //         number.append("6");
        //         break;

        //     case 103:

        //         number.append("7");
        //         break;

        //     case 104:

        //         number.append("8");
        //         break;

        //     case 105:

        //         number.append("9");
        //         break;

        //     case 8:

        //         total = number.text();
        //         total = total.slice(0,-1);
        //         number.empty().append(total);
        //         break;

        //     case 27:

        //         number.empty();
        //         break;

        //     case 106:

        //         number.append("*");
        //         break;

        //     case 35:

        //         number.append("#");
        //         break;

        //     case 13:

        //         $('.pad-action').click();
        //         break;

        //     default: return;
        //}

        e.preventDefault();
    });
});
var callStarted = function()
    {
        window.onbeforeunload = function() {
                return "The call is in progress, are you sure you want to leave?";

            }
            $(".pad-action").addClass('hidden');
            $(".pad-action-disconnect").removeClass('hidden');
            var calledNumber = number.text();
            number.empty();
            $("#calledNumber").text(calledNumber);
            $(".call-details").removeClass("hidden");
            setTimeout(callConnected,5000);

    };
    var callEnded = function()
    {
        window.onbeforeunload = function() {
                

            }
            $(".pad-action-disconnect").addClass('hidden');
            $(".pad-action").removeClass('hidden');
            $(".call-details").addClass("hidden");
            $("#callingStatus").removeClass("hidden");
        $("#callDuration").addClass("hidden");
            number.append($("#calledNumber").text());
            timeCounterCounting=false;
            timeCounter = 0;
    };
    var modelClosed = function()
    {
        number.empty();
    };
    var callConnected = function()
    {
        $("#callingStatus").addClass("hidden");
        $("#callDuration").removeClass("hidden");
        timeCounterCounting = true;
        timeCounterLoop();
    };
    var timeCounterLoop = function () {

        if (timeCounterCounting) {
            setTimeout(function () {
                var timeStringSeconds = '';
                var minutes = Math.floor(timeCounter / 60.0);
                var seconds = timeCounter % 60;
                if (minutes < 10) {
                    minutes = '0' + minutes;
                }
                if (seconds < 10) {
                    seconds = '0' + seconds;
                }
                $("#callDuration").text(minutes + ':' + seconds);

                timeCounter += 1;

                timeCounterLoop();
            }, 1000);
        }
    };