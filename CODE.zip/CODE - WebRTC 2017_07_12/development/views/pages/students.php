<rn:meta title="#rn:msg:SHP_TITLE_HDG#" template="standard.php" clickstream="student"/>

 <!-- apple touch icon -->
    <link rel="icon" sizes="192x192" href="/euf/assets/css/apple-icons/touch-icon-192x192.png">
    <link rel="apple-touch-icon-precomposed" sizes="180x180" href="/euf/assets/css/apple-icons/apple-touch-icon-180x180-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="/euf/assets/css/apple-icons/apple-touch-icon-152x152-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="/euf/assets/css/apple-icons/apple-touch-icon-120x120-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="76x76" href="/euf/assets/css/apple-icons/apple-touch-icon-76x76-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="57x57" href="/euf/assets/css/apple-icons/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="/euf/assets/css/apple-icons/apple-touch-icon-precomposed.png">
    <link href="/euf/assets/css/normalize.css" media="screen,projection" type="text/css" rel="stylesheet" />
    <link href="/euf/assets/css/bootstrap.min.css" media="screen,projection" type="text/css" rel="stylesheet" />
    <link href="/euf/assets/css/font-awesome.min.css" media="screen,projection" type="text/css" rel="stylesheet" />
    <link href="/euf/assets/css/dialpad.css" media="screen,projection" type="text/css" rel="stylesheet" />


<style>
nav ul ul li a {
width: 100%;
padding: 10px 9%;
}
.common{
  width:100%;
}
.m-b-10{
  margin-bottom: 10px; 
}
#rn_MainColumn
{
    width:100% !important;
}
</style>
<script src="/euf/assets/js/modernizr.min.js"></script>

<script src="/euf/assets/js/jquery/jquery-1.9.1.min.js"></script>
<script src="/euf/assets/js/bootstrap.min.js"></script>
<script src="/euf/assets/js/dialpad.js"></script>
<script type="text/javascript" src="//media.twiliocdn.com/sdk/js/client/v1.4/twilio.min.js"></script>

<main class="internal">
<?php
$pageLimit = 15; 
// $roql = "SELECT * FROM SemesterObj.Spring_Status_Fourth";
// $resultSet = RightNow\Connect\v1_1\ROQL::query($roql);
// $queryResults = $resultSet->next();
// while($data = $queryResults->next())
// {
//     var_dump($data);
// }
// die;
?>
<?php 
function paginationLink($total,$limit)
{
   $_GET['page']=(isset($_GET['page']))?$_GET['page']:1;
        echo '<div class="row">'; 
          echo '<div class="col-md-12">';
            $totalrecord_data['total']=$total;
            if($totalrecord_data['total']>0)  
            {
              $lastpage = ceil($totalrecord_data['total']/$limit);
              if($lastpage>1)
              {
                echo '<ul class="pagination">';
                  if(@$_GET['page']>1)
                  {
                    echo '<li><a href="'.$_SERVER['REQUEST_URI'].'?page=1">&laquo;</a></li>';
                  }

                  $maxpage_display = 5;
                  $startpage=1;
                  if($lastpage>$maxpage_display)
                  {
                    $endpage=$maxpage_display;
                  }
                  else
                  {
                    $endpage=$lastpage; 
                  }
                  if(@$_GET['page']<$maxpage_display){$startpage = 1;} 
                  else {
                    $startpage = abs($_GET['page']-2);

                    if(($_GET['page']+2)<$lastpage) {
                      $endpage = abs($_GET['page']+2);
                    }else {$endpage = $lastpage;}
                  }

                  if($startpage>=3)
                  {
                    echo '<li><a href="'.$_SERVER['REQUEST_URI'].'?page='.($startpage-1).'">&larr; Prev</a></li>';
                  }

                  for($a=$startpage;$a<=$endpage;$a++)
                  {
                    if(@$_GET['page']==$a) {
                      echo '<li class="active"><a href="'.$_SERVER['REQUEST_URI'].'?page='.$a.'">'.$a.'</a></li>';
                    } else {
                      echo '<li><a href="'.$_SERVER['REQUEST_URI'].'?page='.$a.'">'.$a.'</a></li>';
                    }
                  }

                  if($endpage<($lastpage-3))
                  {
                    echo '<li><a href="'.$_SERVER['REQUEST_URI'].'?page='.($endpage+1).'">Next &rarr;</a></li>';
                  }
                  
                  if(@$_GET['page']<$lastpage)
                  {
                    echo '<li><a href="'.$_SERVER['REQUEST_URI'].'?page='.$lastpage.'">&raquo;</a></li>';
                  }
                echo '</ul>';
              } 
            }

          echo '</div>';    
        echo '</div>';
}


?>
<div >
  <div class="common" style="text-align:center">
    <?php
    $contacts = $this->model('custom/contact_object_model')->getContactList((isset($_GET['page']))?$_GET['page']:1,$pageLimit);
    
    ?>
    <table  class="table table-hover table-striped">
      <thead style="background-color:#0397db; color:#fff;">
        <tr>
          
          <th align="left">ID</th>
          <th align="left">STUDENT NAME</th>
          <th align="left">EMAIL</th>
          <th >ACTION</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $i=1;
        while($data = $contacts->next())
        {
            $roql = "SELECT contact.Emails.EmailList.Address FROM contact where ID=".$data['ID'];
            $resultSetEmail = RightNow\Connect\v1_1\ROQL::query($roql);
            $queryResultsEmail = $resultSetEmail->next();
            $dataEmail = $queryResultsEmail->next();

            $roqlPhone = "SELECT Contact.Phones.PhoneList.Number FROM Contact WHERE ID = ".$data['ID'];
            $resultSetPhone = RightNow\Connect\v1_1\ROQL::query($roqlPhone);
            $queryResultsPhone = $resultSetPhone->next();
            $phoneString='';
            while($dataPhone = $queryResultsPhone->next())
            {
                $phoneString.=$dataPhone['Number']?'<a  data-toggle="modal" data-target="#studentDetails"  class="openMenu" data-phone="'.$dataPhone['Number'].'" data-id="'.$data['ID'].'" style="cursor:pointer">'.$dataPhone['Number'].'</a><br>':'';
            }
            if($phoneString=='')
            $phoneString = '<a  data-toggle="modal" data-target="#studentDetails"  class="openMenu" data-id="'.$data['ID'].'" style="cursor:pointer">call</a>';
           
        
        ?>
        <tr>
          
          <td align="left"><?= $data['ID'] ?></td>
          <td align="left"><?= $data['LookupName']?></td>
          <td align="left"><?= $dataEmail['Address']?></td>
          <td align="left"><?= $phoneString ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
    <?php 
    paginationLink($this->model('custom/contact_object_model')->getContactCount(),$pageLimit); ?>
    
  </div>
</div>
<div id="studentDetails" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog dial-pad-container">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" onclick="modelClosed();callEnded();">&times;</button>
        
      </div>
      <div class="modal-body">
        <!-- <div class="loader text-center">
          <img src="/euf/assets/images/loading.gif" height="40px">
        </div>
        <div class="modal-data">
          
            
        </div> -->
        <div id="wrapper">
    <div class="dialpad compact">
    	<div class="call-details hidden">
    		<div id="calledNumber">1234567890</div>
    		<div id="callingStatus">calling...</div>
    		<div id="callDuration" class="hidden">00:00</div>
    	</div>
        <div class="number"></div>
        <!-- <div class="phoneString">
        	<input type="number" onKeyPress="if(this.value.length==11)return false;">
        </div> -->
        <div class="dials">
            <ol>
                <li class="digits"><p><strong>1</strong></p></li>
                <li class="digits"><p><strong>2</strong><sup>abc</sup></p></li>
                <li class="digits"><p><strong>3</strong><sup>def</sup></p></li>
                <li class="digits"><p><strong>4</strong><sup>ghi</sup></p></li>
                <li class="digits"><p><strong>5</strong><sup>jkl</sup></p></li>
                <li class="digits"><p><strong>6</strong><sup>mno</sup></p></li>
                <li class="digits"><p><strong>7</strong><sup>pqrs</sup></p></li>
                <li class="digits"><p><strong>8</strong><sup>tuv</sup></p></li>
                <li class="digits"><p><strong>9</strong><sup>wxyz</sup></p></li>
                <li class="digits"><p><strong>*</strong></p></li>
                <li class="digits"><p><strong>0</strong><sup>+</sup></p></li>
                <li class="digits"><p><strong>#</strong></p></li>
                <li class="digits"><p><strong><i class="fa fa-refresh"></i></strong><sup>Clear</sup></p></li>
                <li class="digits"><p><strong><i class="fa fa-times"></i></strong><sup>Delete</sup></p></li>
                <li class="digits pad-action disabled"><p><strong><i class="fa fa-phone"></i></strong> <sup>Call</sup></p></li>
                <li class="digits pad-action-disconnect hidden"><p><strong><i class="fa fa-phone phone-disconnect"></i></strong> <sup>Disconnect</sup></p></li>
            </ol>
        </div>
    </div>
</div>
      </div>
    </div>
  </div>
</div>
</div>
</main>


